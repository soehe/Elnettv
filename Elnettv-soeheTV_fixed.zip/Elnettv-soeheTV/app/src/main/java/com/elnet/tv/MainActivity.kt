package com.elnet.tv

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var statusView: TextView

    // Public HLS test stream. Replace with the official Elnet TV stream later.
    private val streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.player_view)
        statusView = findViewById(R.id.status_view)
        statusView.text = "Elnet TV\nMenyiapkan video..."
        playerView.useController = true
    }

    override fun onStart() {
        super.onStart()
        initializePlayer()
    }

    private fun initializePlayer() {
        if (player != null) return

        try {
            player = ExoPlayer.Builder(this).build().also { exoPlayer ->
                playerView.player = exoPlayer

                exoPlayer.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_BUFFERING -> {
                                statusView.visibility = View.VISIBLE
                                statusView.text = "Elnet TV\nMemuat siaran..."
                            }
                            Player.STATE_READY -> {
                                statusView.visibility = View.GONE
                            }
                            Player.STATE_ENDED -> {
                                statusView.visibility = View.VISIBLE
                                statusView.text = "Siaran selesai"
                            }
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        statusView.visibility = View.VISIBLE
                        statusView.text =
                            "Elnet TV\nGagal memutar siaran.\nPeriksa koneksi internet atau URL stream."
                    }
                })

                exoPlayer.setMediaItem(MediaItem.fromUri(streamUrl))
                exoPlayer.prepare()
                exoPlayer.playWhenReady = true
            }
        } catch (e: Exception) {
            statusView.visibility = View.VISIBLE
            statusView.text =
                "Elnet TV\nAplikasi berjalan, tetapi video gagal dimuat."
        }
    }

    override fun onStop() {
        playerView.player = null
        player?.release()
        player = null
        super.onStop()
    }
}
